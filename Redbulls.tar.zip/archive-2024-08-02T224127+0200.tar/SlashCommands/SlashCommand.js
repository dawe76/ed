const { client, db } = require('../index');

client.on('ready', async () => {
  await client.application.commands.set([
    {
      name: 'تحذير البائع',
      type: 'MESSAGE',
    },
    {
    name : 'remove',
   description : 'To remove a scammer from scammers list',
   options: [ 
{
name: "user",
description: "Id of the scammer",
type: 3,
required: true
    }
   ],
},
{
name : 'check',
description : 'To check if a member is a scammert',
options: [ 
{
name: "user",
description: "Id of the member",
type: 3,
required: true
},
]
}
])
})