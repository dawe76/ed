module.exports = { 
    Posts : {
        here : 50 , 
        every : 10 , 
    }, 

    ads : {
        here : 30 , 
        every : 40 , 
        privteRoom : 80
    }, 

    PrivteRoom : {
        Day7 : 20
    }, 

    RemoveWarns : {
     W25 : 10 , 
     W50 : 20
    }

}